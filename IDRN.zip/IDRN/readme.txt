The framework is developed for graph based node classification.

Recently, we focus on developing the IDRN algorithm.

The first edition appear at APWeb-WAIM Joint Conference on Web and Big Data 2017.
details:
Qi Ye, Changlei Zhu, Gang Li, Feng Wang. Combining Node Identifier Features and Community Priors for Within-Network Classification. APWeb-WAIM Joint Conference, Beijing, China.


Unfortunately, there is one bug in the first edition in the cn.adrs.classifier.graphbased.MultiLabelReader Java file in line 70.
//table.addDataPoint(dataPoint);
This line should be removed, as it makes each data point been added twice and it makes the metrics of IDRN classifier  better. 

We have fixed this bug in the following new article and update the java code:
If our work can help you, please considering citing the following paper: 
Qi Ye, Changlei Zhu, Gang Li, Zhimin Liu an Feng Wang. Using Node Identifiers and Community Prior for Graph-Based Classification. Data Science and Engineering,  March 2018, Volume 3, Issue 1, pp 68�C83.

Thanks very much.
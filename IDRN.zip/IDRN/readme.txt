The framework is developed for graph based node classification.

Recently, we focus on developing the IDRN algorithm.
If you publish a graph based node classification related paper, please considering citing the following paper: 
To be appear at APWeb-WAIM Joint Conference on Web and Big Data 2017.

details:
Qi Ye, Changlei Zhu, Gang Li, Feng Wang. Combining Node Identifier Features and Community Priors for Within-Network Classification. APWeb-WAIM Joint Conference, Beijing, China.
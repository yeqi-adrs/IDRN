package multilabel;

import java.io.IOException;


import java.util.Collection;

import cn.adrs.classifier.graphbased.IDRN;
import cn.adrs.classifier.graphbased.IDRNC;
import cn.adrs.classifier.graphbased.MultiLabelReader;
import cn.adrs.classifier.validation.multilabel.MultiLabelMultiTimeValidation;
import cn.adrs.classifier.validation.multilabel.MultiLabelTrainTestValidator;
import cn.adrs.graph.*;
import cn.adrs.graph.community.CommunityDetection;
import cn.adrs.graph.community.louvain.LouvainAlgorithm;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public class IDRNCValidation 
{
	public static void main(String []args) throws IOException
	{
		String name = "amazon";
		String path = "data/";
		//String name = "wikipedia";
		//String path = "D:/public_dataset/graph_based_classify/";
		
		String graphFile = path + name + "/" +  name + "_edge_format.txt";
		
		Graph graph = NaiveFileGraphReader.readUndirectedGraph(graphFile);
		int m = graph.getVertexSet().size();
		int n = graph.getEdgeNumber();
		
		double ratio = (double)n / m;
		System.out.println(graph.getVertexSet().size());
		System.out.println(graph.getEdgeNumber());
		System.out.println(" edge to node ratio = " + ratio);
		
		
		CommunityDetection algorithm = new LouvainAlgorithm(graph);
		long oldTime = System.currentTimeMillis();
		Collection communities  = algorithm.findCommunities();
		long newTime = System.currentTimeMillis();
		System.out.println("Community number = " + communities.size());
		long second = newTime - oldTime;
		int maxSize = 0;
		
		IDRNC classifier = new IDRNC(graph, communities);
		//Get all the features of the data points
		ClassifyDataTable nodeTable = classifier.getNodeDataTable();
		//Add the labels to the data points 
		String labelFile = path + name + "/" + name + "_label_format.txt";
		MultiLabelReader.readLabels(labelFile, nodeTable);
		
		
		//Evaluate for five times. 
		//Each time use 10% data to train the classifier 
		int times = 5;
		double testRatio = 0.1;
		MultiLabelMultiTimeValidation cvm = new MultiLabelMultiTimeValidation(classifier, nodeTable, times, testRatio);
		cvm.validate();
		double hamming = cvm.getHammingScore();
		double microF1 = cvm.getMicroF1Score();
		double macroF1 = cvm.getMacroF1Score();
		
		System.out.println("Cross-validation hamming rate = " + hamming);
		System.out.println("Cross-validation microF1 rate = " + microF1);
		System.out.println("Cross-validation macroF1 rate = " + macroF1);
	}
}

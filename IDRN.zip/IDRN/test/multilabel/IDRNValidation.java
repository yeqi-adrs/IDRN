package multilabel;

import java.io.IOException;

import cn.adrs.classifier.graphbased.IDRN;
import cn.adrs.classifier.graphbased.MultiLabelReader;
import cn.adrs.classifier.validation.multilabel.MultiLabelMultiTimeValidation;
import cn.adrs.graph.Graph;
import cn.adrs.graph.NaiveFileGraphReader;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public class IDRNValidation 
{
	public static void main(String []args) throws IOException
	{
		String name = "amazon";
		String path = "data/";
		//String name = "wikipedia";
		//String path = "D:/public_dataset/graph_based_classify/";
		
		String graphFile = path + name + "/" +  name + "_edge_format.txt";
		
		Graph graph = NaiveFileGraphReader.readUndirectedGraph(graphFile);
		int m = graph.getVertexSet().size();
		int n = graph.getEdgeNumber();
		
		double ratio = (double)n / m;
		System.out.println(graph.getVertexSet().size());
		System.out.println(graph.getEdgeNumber());
		System.out.println(" edge to node ratio = " + ratio);
		

		IDRN classifier = new IDRN(graph);
		//Get all the features of the data points
		ClassifyDataTable allNodeTable = classifier.getNodeDataTable();
		//Add the labels to the data points
		String labelFile = path + name + "/" + name + "_label_format.txt";
		MultiLabelReader.readLabels(labelFile, allNodeTable);
		
		//Evaluate for five times. 
		//Each time use 10% data to train the classifier 
		int times = 5;
		double testRatio = 0.1;
		MultiLabelMultiTimeValidation cvm = new MultiLabelMultiTimeValidation(classifier, allNodeTable, times, testRatio);
		cvm.validate();
		double hamming = cvm.getHammingScore();
		double microF1 = cvm.getMicroF1Score();
		double macroF1 = cvm.getMacroF1Score();
		
		System.out.println("Cross-validation hamming rate = " + hamming);
		System.out.println("Cross-validation microF1 rate = " + microF1);
		System.out.println("Cross-validation macroF1 rate = " + macroF1);
	}
}

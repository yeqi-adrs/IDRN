package cn.adrs.classifier;

import java.util.List;

import cn.adrs.space.vectorspace.DataPoint;

public interface MultiLabelClassifier extends MultiLabelPredictor, ClassifierTrainer
{
	List<ClassifyResult> classifyLabels(DataPoint instance);
}

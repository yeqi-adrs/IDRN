package cn.adrs.classifier;

public class ClassifyResult implements Comparable
{
	public int label;
	public double score;
	
	public ClassifyResult(int result)
	{
		this.label = result;
		this.score = Double.MIN_VALUE;
	}
	
	public ClassifyResult(int label, double score)
	{
		this.label = label;
		this.score = score;
	}

	@Override
	public int compareTo(Object arg0) 
	{
		ClassifyResult obj = (ClassifyResult)arg0;
		
		if (this.score > obj.score)
		{
			return -1;
		} else if (this.score < obj.score) {
			return 1;
		} else {
			return 0;
		}
	}
}

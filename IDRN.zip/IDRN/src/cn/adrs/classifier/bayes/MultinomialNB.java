package cn.adrs.classifier.bayes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cn.adrs.classifier.Classifier;
import cn.adrs.classifier.ClassifyResult;
import cn.adrs.classifier.MultiLabelClassifier;
import cn.adrs.space.utils.DisFeatureClassKey;
import cn.adrs.space.utils.DisFeatureKey;
import cn.adrs.space.utils.DiscreteObjEstimator;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.Feature;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public class MultinomialNB implements Classifier, MultiLabelClassifier
{
	protected boolean isPriorAdded = false;
	protected HashMap<Integer, Double> classCount; 
	protected HashMap<DisFeatureClassKey, Double> featureClassCount;
	protected int totalInstance = 0;
	protected HashMap<DisFeatureKey, HashMap<Integer, Double>> featureClassListMap;	

	public MultinomialNB(boolean isPreOpen)
	{
		this.isPriorAdded = isPreOpen;
	}
	
	public void init()
	{
		totalInstance = 0;
		classCount = new HashMap<Integer, Double>();
		featureClassCount = new HashMap<DisFeatureClassKey, Double>();
		featureClassListMap = new HashMap<DisFeatureKey, HashMap<Integer, Double>>();
	}
	
	public int getDataPointNum()
	{
		return this.totalInstance;
	}
	
	@Override
	public void train(ClassifyDataTable trainData) 
	{
		init();
		
		for (int i = 0; i < trainData.getDataPointNum(); i++)
		{
			DataPoint instance = trainData.getDataPoint(i);
			if (instance.isMultiLabel() == false)
			{
				int label = instance.getClassLabel();
			
				this.trainInstance(label, instance);
			} else {
				Iterator labelIter = instance.getLabelSet().iterator();
    			while (labelIter.hasNext())
    			{
    				int label = (Integer)labelIter.next();
    				this.trainInstance(label, instance);
    			}
			}
		}//end for i
	}
	
	public void trainInstance(int classID, DataPoint features)
	{
		Iterator iter = features.getFeatures();
		while (iter.hasNext())
		{
			totalInstance++;
			
			increaseClassCounterInstance(classID);
			
			Feature featureNode = (Feature)iter.next();
			
			increaseFeatureClassCounterInstance(featureNode, classID);
			
			updateFeatureRelateClassIndex(featureNode, classID);
		}//end for
	}
	
	protected void increaseFeatureClassCounterInstance(Feature feature, int classID) 
	{
		long id = feature.getFeatureID();
		int value = feature.getIntValue();
		
		DisFeatureClassKey fcv = new DisFeatureClassKey(id, value, classID);

		increaseFeatureClassCounterInstance(fcv);
	}
	
	private void updateFeatureRelateClassIndex(Feature feature, int classID)
	{
		DisFeatureKey featureKey = new DisFeatureKey(feature.getFeatureID(), feature.getIntValue());
		
		HashMap<Integer, Double> classCounterMap;
		if (featureClassListMap.containsKey(featureKey))
		{
			classCounterMap = featureClassListMap.get(featureKey);
		} else {
			classCounterMap = new HashMap<Integer, Double>();
			featureClassListMap.put(featureKey, classCounterMap);
		}
		
		if (classCounterMap.containsKey(classID))
		{
			double value = classCounterMap.get(classID);
			value++;
			classCounterMap.put(classID, value);
		} else {
			classCounterMap.put(classID, 1.0);
		}
	}
	
	private void increaseFeatureClassCounterInstance(DisFeatureClassKey key)
	{
		double value;
		if(featureClassCount.containsKey(key)) 
		{
			value = featureClassCount.get(key);
			featureClassCount.put(key, value + 1);
		} else {
			featureClassCount.put(key, 1.0);
		}
	}
	
	public void increaseClassCounterInstance(int classValue)
	{
		double value;
		if (classCount.containsKey(classValue)) 
		{
			value = classCount.get(classValue);
			classCount.put(classValue, value+1);
		} else {
			classCount.put(classValue, 1.0);
		}
	}
	
	public double getApriorProbabilty(Comparable classID)
	{
		double classNum = classCount.get(classID);
		
		double classValue = classNum / totalInstance;
		
		return classValue;
	}
	
	public void getRelatedClass(DisFeatureKey featureKey, HashSet totalSelectedSet)
	{
		if (featureClassListMap.containsKey(featureKey))
		{
			HashMap<Integer, Double> map = this.featureClassListMap.get(featureKey);
			
			Iterator iter = map.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>)iter.next();
				
				totalSelectedSet.add(entry.getKey());
			}//end while
		}//end if
	}
	
	public double getConditionalProbability(DisFeatureClassKey featureClassKey) 
	{	
		double vectorNum = 0;
		if (featureClassCount.containsKey(featureClassKey))
		{
			vectorNum = featureClassCount.get(featureClassKey) + 1;
		} else{
			vectorNum = 1;
		}
		
		int classLabel = featureClassKey.classLabel;
		
		double classNum = 0;
		if (classCount.containsKey(classLabel))
		{
			classNum = classCount.get(classLabel) + this.featureClassListMap.size();
		} else {
			classNum = this.featureClassListMap.size();
		}
		
		return vectorNum / classNum;
	}
	
	public HashMap<Integer, Double> predictInstance(DataPoint instance) 
	{
		HashMap<Integer, Double> result = new HashMap<Integer, Double>();
		
		HashSet selectedClassSet = new HashSet();
		
		Iterator featureIter = instance.getFeatures();
		while (featureIter.hasNext())
		{
			Feature feature = (Feature)featureIter.next();
			
			DisFeatureKey featureKey = new DisFeatureKey(feature.getFeatureID(), feature.getIntValue());
			
			getRelatedClass(featureKey, selectedClassSet);
		}
		
		if (selectedClassSet.size() == 0)
		{
			Iterator iter = this.classCount.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				int label = entry.getKey();
				
				selectedClassSet.add(label);
			}
		}
		
		Iterator iter = selectedClassSet.iterator();
		while (iter.hasNext()) 
		{
			int classID = (Integer)iter.next();
			double predictValue = 0.0;
			
			featureIter = instance.getFeatures();
			while (featureIter.hasNext())
			{
				Feature feature = (Feature)featureIter.next();
				
				DisFeatureClassKey featureClassKey = new DisFeatureClassKey(feature.getFeatureID(), feature.getIntValue(), classID);
				
				double conditionalPorb = getConditionalProbability(featureClassKey);
				
				predictValue += Math.log(conditionalPorb);
			}
			
			//add a prior probability
			if (isPriorAdded)
			{
				double aprior = getApriorProbabilty(classID);
				predictValue += Math.log(aprior);
			}
			
			result.put(classID, predictValue);
		}//end while
		
		return result;
	}
	
	public HashMap<Integer, Double> predictInstance(DataPoint instance, DiscreteObjEstimator plugInPriors) 
	{
		HashMap<Integer, Double> result = new HashMap<Integer, Double>();
		
		HashSet selectedClassSet = new HashSet();
		
		Iterator featureIter = instance.getFeatures();
		while (featureIter.hasNext())
		{
			Feature feature = (Feature)featureIter.next();
			
			DisFeatureKey featureKey = new DisFeatureKey(feature.getFeatureID(), feature.getIntValue());
			
			getRelatedClass(featureKey, selectedClassSet);
		}
		
		if (selectedClassSet.size() == 0)
		{
			Iterator iter = this.classCount.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				int label = entry.getKey();
				
				selectedClassSet.add(label);
			}
		}
		
		Iterator iter = selectedClassSet.iterator();
		while (iter.hasNext()) 
		{
			int classID = (Integer)iter.next();
			double predictValue = 0.0;
			
			featureIter = instance.getFeatures();
			while (featureIter.hasNext())
			{
				Feature feature = (Feature)featureIter.next();
				
				DisFeatureClassKey featureClassKey = new DisFeatureClassKey(feature.getFeatureID(), feature.getIntValue(), classID);
				
				double conditionalPorb = getConditionalProbability(featureClassKey);
				
				predictValue += Math.log(conditionalPorb);
			}
			
			//add a prior probability
			if (isPriorAdded)
			{
				double aprior = plugInPriors.getValue(classID);
				predictValue += Math.log(aprior);
			}
			
			result.put(classID, predictValue);
		}//end while
		
		return result;
	}
	
	protected int getMaxClassID(HashMap<Integer, Double> map) 
	{
		int maxClassID = Integer.MIN_VALUE;
		double maxPredictValue = Double.NEGATIVE_INFINITY;
		
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Comparable, Double> entry = (Map.Entry<Comparable, Double>)iter.next();
			double predictValue = entry.getValue();
			int classValue = (Integer)entry.getKey();
			
			if (predictValue > maxPredictValue) 
			{
				maxPredictValue = predictValue;
				maxClassID = classValue;
			}
		}
		
		return maxClassID;
	}
	
	public List<ClassifyResult> classifyLabels(DataPoint instance,
			DiscreteObjEstimator plugInPriors) 
	{
		HashMap<Integer, Double> results = predictInstance(instance, plugInPriors);
		
		ArrayList<ClassifyResult> resultList = new ArrayList();
		
		int labelObj = this.getMaxClassID(results);
		
		double maxClassScore = results.get(labelObj);
		double sum = 0;
		
		Iterator iter = results.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				
			double score = entry.getValue();
			double delta = score - maxClassScore;
				
			double value = Math.exp(delta);
				
			sum += value;
		}
		
		
		iter = results.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				
			int label = entry.getKey();
			double score = entry.getValue();
			double delta = score - maxClassScore;
				
			double value = Math.exp(delta);
				
			double prob = value / sum;
		
			ClassifyResult result = new ClassifyResult(label, prob);
			resultList.add(result);
		}
		
		Collections.sort(resultList);
		
		return resultList;
	}
	
	public ClassifyResult classify(DataPoint instance, DiscreteObjEstimator plugInPriors) 
	{
		HashMap<Integer, Double> results = predictInstance(instance, plugInPriors);
		
		int labelObj = this.getMaxClassID(results);
		
		ClassifyResult classifyResult = new ClassifyResult(labelObj);
			
		if (results.containsKey(labelObj))
		{
			double maxClassScore = results.get(labelObj);
				
			double sum = 0;
			
			Iterator iter = results.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
					
				double score = entry.getValue();
				double delta = score - maxClassScore;
					
				double value = Math.exp(delta);
					
				sum += value;
			}
				
			double prob = 1.0 / sum;
				
			classifyResult.score = prob;
		} else {
			classifyResult.score = 0;
		}
			
			
		return classifyResult;
	}

	@Override
	public ClassifyResult classify(DataPoint instance) 
	{
		HashMap<Integer, Double> results = predictInstance(instance);
		
		int labelObj = this.getMaxClassID(results);
		
		ClassifyResult classifyResult = new ClassifyResult(labelObj);
			
		if (results.containsKey(labelObj))
		{
			double maxClassScore = results.get(labelObj);
				
			double sum = 0;
			
			Iterator iter = results.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
					
				double score = entry.getValue();
				double delta = score - maxClassScore;
					
				double value = Math.exp(delta);
					
				sum += value;
			}
				
			double prob = 1.0 / sum;
				
			classifyResult.score = prob;
		} else {
			classifyResult.score = 0;
		}
			
			
		return classifyResult;
	}
	
	public List<ClassifyResult> classifyLabels(DataPoint instance)
	{
		HashMap<Integer, Double> results = predictInstance(instance);
		
		
		ArrayList<ClassifyResult> resultList = new ArrayList();
		
		int labelObj = this.getMaxClassID(results);
		
		double maxClassScore = results.get(labelObj);
		double sum = 0;
		
		Iterator iter = results.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				
			double score = entry.getValue();
			double delta = score - maxClassScore;
				
			double value = Math.exp(delta);
				
			sum += value;
		}
		
		
		iter = results.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry<Integer, Double>)iter.next();
				
			int label = entry.getKey();
			double score = entry.getValue();
			double delta = score - maxClassScore;
				
			double value = Math.exp(delta);
				
			double prob = value / sum;
		
			ClassifyResult result = new ClassifyResult(label, prob);
			resultList.add(result);
		}
		
		Collections.sort(resultList);
		
		return resultList;
	}
}

package cn.adrs.classifier.graphbased;

import java.util.*;

import cn.adrs.classifier.ClassifyResult;
import cn.adrs.classifier.bayes.MultinomialNB;
import cn.adrs.graph.*;
import cn.adrs.graph.community.Community;
import cn.adrs.space.utils.DiscreteObjEstimator;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.Feature;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;
import cn.adrs.space.vectorspace.table.ClassifyDataTableImpl;

public class IDRNC implements GraphBasedClassifier
{
	private Graph graph;
	private MultinomialNB mnb;
	private HashMap<Vertex, DataPoint> vertexPointMap = new HashMap();
	private ClassifyDataTable dataset;
	
	private HashMap<Vertex, Community> nodeToCommunityMap;
	private Collection<Community> communities;
	private HashMap<Community, DiscreteObjEstimator> communityPriorMap;
	private DiscreteObjEstimator globalPrior;

	public IDRNC(Graph graph, Collection<Community> communities)
	{
		this.graph = graph;
		this.communities = communities;
		
		initNodeDataTable();
		initNodeToCommunity();
	}
	
	public void initNodeToCommunity()
	{
		nodeToCommunityMap = new HashMap();
		
		Iterator iter = this.communities.iterator();
		while (iter.hasNext())
		{
			Community community = (Community)iter.next();
			
			Iterator nodeIter = community.getVertexIterator();
			while (nodeIter.hasNext())
			{
				Vertex node = (Vertex)nodeIter.next();
				
				nodeToCommunityMap.put(node, community);
			}//end while
		}//end while 
	}
	
	public ClassifyDataTable getNodeDataTable()
	{
		return this.dataset;
	}
	
	public void initNodeDataTable()
	{
		dataset = new ClassifyDataTableImpl();
		
		Iterator iter = graph.getVertexIterator();
		while (iter.hasNext())
		{
			Vertex vertex = (Vertex)iter.next();
			int id = (Integer)vertex.getID();
			
			DataPoint point =  new DataPointImpl();
			point.setID(id);
			initNeighborFeatures(point, vertex);
			
			dataset.addDataPoint(point);
			
			vertexPointMap.put(vertex, point);
		}
	}
	
	public void initNeighborFeatures(DataPoint point, Vertex vertex)
	{
		int selfID = (Integer)vertex.getID();
		Feature selfFeature = new Feature(selfID, 1);
		point.addFeature(selfFeature);
		
		Iterator iter = vertex.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
				
			Vertex adj = edge.getAdjVertex(vertex);
			int id = (Integer)adj.getID();
				
			Feature feature = new Feature(id, 1);
			point.addFeature(feature);
		}
	}
	
	public void init()
	{
		mnb = new MultinomialNB(true);
		globalPrior = new DiscreteObjEstimator();
	}
	
	public void initUniformPrior(Set labelSet)
	{
		communityPriorMap = new HashMap();
		
		Iterator iter = communities.iterator();
		while (iter.hasNext())
		{
			Community community = (Community)iter.next();
			DiscreteObjEstimator prior = new DiscreteObjEstimator();
			
			Iterator labelIter = labelSet.iterator();
			while (labelIter.hasNext())
			{
				int label = (Integer)labelIter.next();
				
				prior.addValue(label, 1);
			}
			
			communityPriorMap.put(community, prior);
		}
		
		iter = labelSet.iterator();
		while (iter.hasNext())
		{
			Object label = iter.next();
			this.globalPrior.addValue(label, 1);
		}
	}
	
	@Override
	public List<ClassifyResult> classifyLabels(DataPoint point) 
	{
		Object id = point.getID();
		
		Vertex v = graph.getVertex(id);

		List<ClassifyResult> results;
		if (v != null)
		{
			results = classifyLabels(v);
		}else{
			System.out.println(id + "is not in the graph");
			
			results = new ArrayList();
		}
		
		return results;
	}
	

	@Override
	public void train(ClassifyDataTable trainData) 
	{	
		init();
		
		double hitDataPointNum = 0.0;
		
		Set totalLabelSet = trainData.getClassLabelSet();
		initUniformPrior(totalLabelSet);
		
		mnb.train(trainData);
		
		HashSet<Community> priorHitSet = new HashSet(); 
		
		for (int i = 0; i < trainData.getDataPointNum(); i++)
		{
			DataPoint point = trainData.getDataPoint(i);
			Object id = point.getID();
			
			Vertex vertex = graph.getVertex(id);
			Community community = this.nodeToCommunityMap.get(vertex);
			DiscreteObjEstimator prior = this.communityPriorMap.get(community);
			
			priorHitSet.add(community);
			
			if (point.isMultiLabel())
			{
				Set labelSet = point.getLabelSet();
				
				Iterator iter = labelSet.iterator();
				while (iter.hasNext())
				{
					int label = (Integer)iter.next();
					
					globalPrior.addValue(label, 1);
					prior.addValue(label, 1);
					hitDataPointNum += 1;
				}
			} else if (point.isLabeled()) {
				int label = point.getClassLabel();
				
				globalPrior.addValue(label, 1);
				prior.addValue(label, 1);
				hitDataPointNum += 1;
			}
		}//end
		
		
		int modelNum = mnb.getDataPointNum();
		double scaleFactor = 1.0 / (modelNum + totalLabelSet.size());
		
		globalPrior.scale(scaleFactor);
		Iterator iter = communityPriorMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Community, DiscreteObjEstimator> entry = (Map.Entry)iter.next();
			Community community = entry.getKey();
			
			if (priorHitSet.contains(community) == false)
			{
				communityPriorMap.put(community, globalPrior);
			}else{
				DiscreteObjEstimator communityPrior = entry.getValue();
				communityPrior.scale(scaleFactor);
			}
		}
	}

	@Override
	public List<ClassifyResult> classifyLabels(Vertex vertex) 
	{
		DiscreteObjEstimator estimator = new DiscreteObjEstimator();
		
		DataPoint vertexPoint = vertexPointMap.get(vertex);
		Community community = this.nodeToCommunityMap.get(vertex);
		DiscreteObjEstimator plugInPriors = this.communityPriorMap.get(community);
		
		List<ClassifyResult> results = mnb.classifyLabels(vertexPoint, plugInPriors);
		
		for (int i = 0; i < results.size(); i++)
		{
			ClassifyResult result = results.get(i);
			
			int label = result.label;
			double prob = result.score;
			
			estimator.addValue(label, prob);
		}
		
		ArrayList<ClassifyResult> resultList = new ArrayList();
		
		
		Iterator iter = estimator.getEntries();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry)iter.next();
				
			int label = entry.getKey();
			double prob = estimator.getProbability(label);
				
			ClassifyResult result = new ClassifyResult(label, prob);
			resultList.add(result);
		}
		
		Collections.sort(resultList);
		
		return resultList;
	}
}

package cn.adrs.classifier.graphbased;

import java.util.*;

import cn.adrs.classifier.ClassifyResult;
import cn.adrs.classifier.bayes.MultinomialNB;
import cn.adrs.graph.*;
import cn.adrs.space.utils.DiscreteObjEstimator;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.Feature;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;
import cn.adrs.space.vectorspace.table.ClassifyDataTableImpl;

public class IDRN implements GraphBasedClassifier
{
	private Graph graph;
	private MultinomialNB mnb;
	private HashMap<Vertex, DataPoint> vertexPointMap = new HashMap();
	private ClassifyDataTable dataset;

	public IDRN(Graph graph)
	{
		this.graph = graph;
		
		initNodeDataTable();
	}
	
	public ClassifyDataTable getNodeDataTable()
	{
		return this.dataset;
	}
	
	public void initNodeDataTable()
	{
		dataset = new ClassifyDataTableImpl();
		
		Iterator iter = graph.getVertexIterator();
		while (iter.hasNext())
		{
			Vertex vertex = (Vertex)iter.next();
			int id = (Integer)vertex.getID();
			
			DataPoint point =  new DataPointImpl();
			point.setID(id);
			initEgoGraphFeatures(point, vertex);
			
			dataset.addDataPoint(point);
			
			vertexPointMap.put(vertex, point);
		}
	}
	
	public void initEgoGraphFeatures(DataPoint point, Vertex vertex)
	{
		int selfID = (Integer)vertex.getID();
		Feature selfFeature = new Feature(selfID, 1);
		point.addFeature(selfFeature);
		
		Iterator iter = vertex.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
				
			Vertex adj = edge.getAdjVertex(vertex);
			int id = (Integer)adj.getID();
				
			Feature feature = new Feature(id, 1);
			point.addFeature(feature);
		}
	}
	
	public void init()
	{
		mnb = new MultinomialNB(true);
	}
	
	@Override
	public List<ClassifyResult> classifyLabels(DataPoint point) 
	{
		Object id = point.getID();
		
		Vertex v = graph.getVertex(id);

		List<ClassifyResult> results;
		if (v != null)
		{
			results = classifyLabels(v);
		}else{
			System.out.println(id + "is not in the graph");
			
			results = new ArrayList();
		}
		
		return results;
	}
	

	@Override
	public void train(ClassifyDataTable trainData) 
	{	
		init();
		
		mnb.train(trainData);
	}

	@Override
	public List<ClassifyResult> classifyLabels(Vertex vertex) 
	{
		DiscreteObjEstimator estimator = new DiscreteObjEstimator();
		
		DataPoint vertexPoint = vertexPointMap.get(vertex);
		List<ClassifyResult> results = mnb.classifyLabels(vertexPoint);
		
		for (int i = 0; i < results.size(); i++)
		{
			ClassifyResult result = results.get(i);
			
			int label = result.label;
			double prob = result.score;
			
			estimator.addValue(label, prob);
		}
		
		
		ArrayList<ClassifyResult> resultList = new ArrayList();
		
		
		Iterator iter = estimator.getEntries();
		while (iter.hasNext())
		{
			Map.Entry<Integer, Double> entry = (Map.Entry)iter.next();
				
			int label = entry.getKey();
			double prob = estimator.getProbability(label);
				
			ClassifyResult result = new ClassifyResult(label, prob);
			resultList.add(result);
		}
		
		Collections.sort(resultList);
		
		return resultList;
	}
}

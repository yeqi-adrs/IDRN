package cn.adrs.classifier.graphbased;

import java.util.List;


import cn.adrs.classifier.ClassifyResult;
import cn.adrs.classifier.MultiLabelClassifier;
import cn.adrs.graph.*;

public interface GraphBasedClassifier extends MultiLabelClassifier
{
	List<ClassifyResult> classifyLabels(Vertex v);
}

package cn.adrs.classifier.graphbased;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.Feature;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public class MultiLabelReader 
{
	public static void readLabels(String file, ClassifyDataTable table) throws IOException 
	{
		BufferedReader reader = new BufferedReader(new FileReader(file));
		
		HashMap<Integer, DataPoint> idToDataPointMap = new HashMap();
		for (int i = 0; i < table.getDataPointNum(); i++)
		{
			DataPoint point = table.getDataPoint(i);
			int id = (Integer)point.getID();
			
			idToDataPointMap.put(id, point);
		}
	
		String line;
        while ((line = reader.readLine()) != null)
        {
        	if (line.startsWith("#"))
        	{
        		//skip the comments
        		continue;
        	}
        	
        	String[] tokens = line.split("\\s+");
       
        	
        	int id = Integer.parseInt(tokens[0]);
        	
        	if (idToDataPointMap.containsKey(id) == false)
        	{
        		System.out.println("Can not find the vertex id = " + id);
        		continue;
        	}
        	DataPoint dataPoint = idToDataPointMap.get(id);
        	
        	String []labels = tokens[1].split(",");
        	for (int i =0; i < labels.length; i++)
        	{
        		int label = Integer.parseInt(labels[i]);
        		dataPoint.addLabel(label);
        	}
            
            for (int j = 2; j < tokens.length; j++) 
            {
            	String[] terms = tokens[j].split(":");
                long index = Long.parseLong(terms[0]);
                
                double value = Double.parseDouble(terms[1]);
                Feature feature = new Feature(index, value);
                    
                dataPoint.addFeature(feature);
            }//end for tokens

            dataPoint.setID(id);
            
            dataPoint.sortIndex();
            //table.addDataPoint(dataPoint);
        }
        
        reader.close();
    }
}

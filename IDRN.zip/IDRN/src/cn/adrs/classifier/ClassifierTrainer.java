package cn.adrs.classifier;

import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public interface ClassifierTrainer 
{
	void train(ClassifyDataTable trainData);
}

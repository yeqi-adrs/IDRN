package cn.adrs.classifier;

import cn.adrs.space.vectorspace.DataPoint;

public interface ClassifyPredictor 
{
	ClassifyResult classify(DataPoint instance);
}

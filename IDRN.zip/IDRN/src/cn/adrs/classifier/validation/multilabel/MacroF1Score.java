package cn.adrs.classifier.validation.multilabel;

import java.util.*;

import cn.adrs.classifier.ClassifyResult;

/*
 * Large Scale Multi-Label Classification via MetaLabeler
 * Lei Tang et al.
 * Arizona State University
 */
public class MacroF1Score 
{
	class F1Record
	{
		double numerator = 0.0;
		private double denominatorTrueLabel = 0;
		private double denominatorPredLabel = 0;
	}
	
	private HashMap<Integer, F1Record> labelF1RecordMap = new HashMap();
	private int totalNum = 0;
	
	public MacroF1Score(Set<Integer> labelSet)
	{
		Iterator<Integer> iter = labelSet.iterator();
		while (iter.hasNext())
		{
			int label = iter.next();
			F1Record record = new F1Record();
			
			this.labelF1RecordMap.put(label, record);
		}
		
		totalNum = 0;
	}
	
	public void statics(Set<Integer> labelSet, List<ClassifyResult> preList)
	{
		HashSet preLabelSet = new HashSet();
		for (int i = 0; i < preList.size() && i < labelSet.size(); i++)
		{
			ClassifyResult result = preList.get(i);
			int preLabel = result.label;
			preLabelSet.add(preLabel);
		}
		
		Iterator iter = this.labelF1RecordMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, F1Record> entry = (Map.Entry<Integer, F1Record>)iter.next();
			
			int label = entry.getKey();
			F1Record record = entry.getValue();
			
			if (labelSet.contains(label) && preLabelSet.contains(label))
			{
				record.numerator += 2;
			} 
			if (labelSet.contains(label))
			{
				record.denominatorTrueLabel++;
			}
			if (preLabelSet.contains(label))
			{
				record.denominatorPredLabel++;
			}
		}
		
		totalNum++;
	}
	
	public double getScore()
	{
		double result = 0.0;
		
		Iterator iter = this.labelF1RecordMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Integer, F1Record> entry = (Map.Entry<Integer, F1Record>)iter.next();
			
			int label = entry.getKey();
			F1Record record = entry.getValue();
			
			result += record.numerator / (record.denominatorTrueLabel + record.denominatorPredLabel);
		}
		
		return result / this.labelF1RecordMap.size();
	}
}

package cn.adrs.classifier.validation.multilabel;

import java.util.*;

import cn.adrs.classifier.ClassifyResult;

public class HammingScore 
{
	private int totalNum = 0;
	private double totalScore = 0;
	
	public void statics(Set<Integer> labelSet, List<ClassifyResult> preList)
	{
		double hit = 0;
		
		HashSet preLabelSet = new HashSet();
		
		for (int i = 0; i < preList.size() && i < labelSet.size(); i++)
		{
			ClassifyResult result = preList.get(i);
			int preLabel = result.label;
			preLabelSet.add(preLabel);
			
			if (labelSet.contains(preLabel))
			{
				hit++;
			}
		}
		
		double sum = labelSet.size() + preLabelSet.size() - hit;
		double score = hit / sum;
		
		//System.out.println("hit = " + hit + " sum = " + sum + " score = " + score);
		totalScore += score;
		this.totalNum++;
	}
	
	public double getScore()
	{
		//System.out.println("Hamming Score = ");
		//System.out.println(totalScore + "\t" + this.totalNum);
		return this.totalScore / this.totalNum;
	}
}

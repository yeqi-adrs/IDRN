package cn.adrs.classifier.validation.multilabel;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Random;

import cn.adrs.classifier.MultiLabelClassifier;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;
import cn.adrs.space.vectorspace.table.ClassifyDataTableImpl;

public class MultiLabelMultiTimeValidation implements MultiLabelValidation
{
	private boolean isMsgShow = true;
	private double trainDataPercent;
	private int foldNum;
	private ClassifyDataTable data;
	private MultiLabelClassifier classifier;
	private Random random = new Random();
	private double hammingRate;
	private double microF1Rate = 0;
	private double macroF1Score = 0;
	
	
	public MultiLabelMultiTimeValidation(MultiLabelClassifier classifier, ClassifyDataTable data, int foldNum, double trainDataPercent)
	{
		this.classifier = classifier;
		this.data = data;
		this.foldNum = foldNum;
		this.trainDataPercent = trainDataPercent;
	}
	
	public void setIsMsgShow(boolean flag)
	{
		this.isMsgShow = flag;
	}
	
	
	public double getHammingScore()
	{
		return this.hammingRate;
	}
	
	public double getMacroF1Score()
	{
		return this.macroF1Score;
	}
	
	public double getMicroF1Score()
	{
		return this.microF1Rate;
	}
	
	public void validate()
	{
		double result = 0;
		double totalMicroF1Score = 0;
		double totalMacroF1Score = 0;
		
		for (int i = 0; i < foldNum; i++)
		{
			this.data.randomize();
			
			ClassifyDataTable testInstances;
			ClassifyDataTable trainInstances;
			
			testInstances = new ClassifyDataTableImpl();
			trainInstances = new ClassifyDataTableImpl();
			
			
			for (int j = 0; j < this.data.getDataPointNum(); j++)
			{
				DataPoint dataPoint = this.data.getDataPoint(j);
				
				double rand = random.nextDouble();
				if (rand < this.trainDataPercent)
				{
					trainInstances.addDataPoint(dataPoint);
				} else {
					testInstances.addDataPoint(dataPoint);
				}
			}
			
			classifier.train(trainInstances);
			
			MultiLabelTrainTestValidator checker = new MultiLabelTrainTestValidator(testInstances, classifier);
			checker.valicate();
			double hamming = checker.getHammingScore();
			double microF1 = checker.getMicroF1Score();
			double macroF1 = checker.getMacroF1Score();
			
			
			
			if (isMsgShow)
			{
				System.out.println("hamming = " + hamming);
				System.out.println("microF1 = " + microF1);
				System.out.println("macroF1 = " + macroF1);
			}
			
			result += hamming;
			
			totalMicroF1Score += checker.getMicroF1Score();
			totalMacroF1Score += checker.getMacroF1Score();
		}
		
		hammingRate =  result / foldNum;
		microF1Rate = totalMicroF1Score / foldNum;
		macroF1Score = totalMacroF1Score / foldNum;
	}
}

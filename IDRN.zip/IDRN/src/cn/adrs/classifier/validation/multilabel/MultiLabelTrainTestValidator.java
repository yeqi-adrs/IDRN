package cn.adrs.classifier.validation.multilabel;

import java.util.*;
import cn.adrs.classifier.Classifier;
import cn.adrs.classifier.ClassifyPredictor;
import cn.adrs.classifier.ClassifyResult;
import cn.adrs.classifier.MultiLabelPredictor;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;

public class MultiLabelTrainTestValidator
{	
	private ClassifyDataTable testInstances;
	private MultiLabelPredictor predictor;
	private HammingScore hammingScore = new HammingScore();
	private MicroF1Score microF1Score = new MicroF1Score();
	private MacroF1Score macroF1Score;
	
	
	public MultiLabelTrainTestValidator(ClassifyDataTable dataSet, MultiLabelPredictor predictor)
	{
		this.testInstances = dataSet;
		this.predictor = predictor;
		macroF1Score = new MacroF1Score(dataSet.getClassLabelSet());
	}
	
	public void valicate()
	{	
		for (int i = 0; i < testInstances.getDataPointNum(); i++)
		{	
			DataPoint instance = testInstances.getDataPoint(i);
			
			if (instance.isLabeled())
			{
				Set labelSet = instance.getLabelSet();
		
				List<ClassifyResult> preList = predictor.classifyLabels(instance);
				
				hammingScore.statics(labelSet, preList);
				microF1Score.statics(labelSet, preList);
				macroF1Score.statics(labelSet, preList);
			}//end if
		}//end while 
	}
	
	public double getMacroF1Score()
	{
		return this.macroF1Score.getScore();
	}
	
	public double getHammingScore()
	{
		return this.hammingScore.getScore();
	}
	
	public double getMicroF1Score()
	{
		return this.microF1Score.getScore();
	}
}

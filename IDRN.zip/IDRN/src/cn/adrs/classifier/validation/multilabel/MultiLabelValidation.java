package cn.adrs.classifier.validation.multilabel;

public interface MultiLabelValidation 
{
	void validate();
	
	double getHammingScore();
	
	double getMacroF1Score();
	
	double getMicroF1Score();
}

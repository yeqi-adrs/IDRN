package cn.adrs.classifier.validation.multilabel;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.adrs.classifier.ClassifyResult;

public class MicroF1Score 
{
	private double numerator = 0;
	private double denominatorTrueLabel = 0;
	private double denominatorPredLabel = 0;
	
	public void statics(Set<Integer> labelSet, List<ClassifyResult> preList)
	{
		double hit = 0;
		
		HashSet preLabelSet = new HashSet();
		
		for (int i = 0; i < preList.size() && i < labelSet.size(); i++)
		{
			ClassifyResult result = preList.get(i);
			int preLabel = result.label;
			preLabelSet.add(preLabel);
			
			if (labelSet.contains(preLabel))
			{
				hit++;
			}
		}
		
		this.numerator += 2 * hit;
		
		denominatorTrueLabel += labelSet.size();
		denominatorPredLabel += preLabelSet.size();
		
//		System.out.println("hit = " + hit + " denominator = " + labelSet.size() + preLabelSet.size());

		
	}
	
	public double getScore()
	{
//		System.out.println("MicroF1 Score = ");
//		System.out.println("numerator = " + this.numerator);
//		System.out.println("denominator \t TrueLabel " + this.denominatorTrueLabel);
//		System.out.println("denominator \t PredLabel " + this.denominatorPredLabel);
		return this.numerator / (this.denominatorTrueLabel + denominatorPredLabel);
	}
}	

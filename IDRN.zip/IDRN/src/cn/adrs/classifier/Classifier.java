package cn.adrs.classifier;

import java.util.Set;

import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.table.ClassifyDataTable;


public interface Classifier extends ClassifyPredictor, ClassifierTrainer
{
	ClassifyResult classify(DataPoint instance);
}

package cn.adrs.graph;

import java.io.*;

import java.util.*;

public class Graph
{
	private Set vertexSet;
	private Set edgeSet;
	private HashMap vertexMap;
	private boolean isSelfLoop;
	private HashMap graphDataMap;
	private boolean isIDComparable;
	
	
	/**
	 * Constructor. Creates a new undirected graph instance. 
	 */
	public Graph()
	{
		vertexSet = new HashSet();
		edgeSet = new HashSet();
		vertexMap = new HashMap();
		isSelfLoop = false;
		this.isIDComparable = true;
	}
	
	
	public Set getEdgeSet()
	{
		return edgeSet;
	}
	
	public Set getVertexSet()
	{
		return vertexSet;
	}
	
	
	public boolean addEdge(Object src, Object dst)
	{
		if (((src instanceof Comparable) == false) || ((dst instanceof Comparable) == false))
		{
			this.isIDComparable = false;
		}
		
		if (!vertexMap.containsKey(src)){
			Vertex srcVertex = new Vertex(src);
			vertexMap.put(src, srcVertex);
			this.vertexSet.add(srcVertex);
		}
		if (!vertexMap.containsKey(dst)){
			Vertex dstVertex = new Vertex(dst);
			vertexMap.put(dst, dstVertex);
			vertexSet.add(dstVertex);
		}
		Vertex fromVertex = (Vertex)vertexMap.get(src);
		Vertex toVertex = (Vertex)vertexMap.get(dst);
		
		//no self-loop
		if (isSelfLoop == false)
		{
			if (fromVertex.equals(toVertex))
			{
				return false;
			}
		}
		
//		the edge can appear just once, and we will not allow multi-edges
		Iterator adjIter = fromVertex.getEdges();
		while (adjIter.hasNext()) 
		{
			Edge edge = (Edge)adjIter.next();
			Vertex from = edge.getFirstVertex();
			Vertex to = edge.getSecondVertex();
			
			if ((from == fromVertex) && (to == toVertex))
			{
				return false;
			}
			
			if ((to == fromVertex) && (from == toVertex))
			{
				return false;
			}
		}
		
		Edge edge = new Edge();
		edge.setFirstVertex(fromVertex);
		edge.setSecondVertex(toVertex);
		fromVertex.addEdge(edge);
		toVertex.addEdge(edge);
		this.edgeSet.add(edge);
		
		return true;
	}
	
	public boolean isVertexExist(Vertex vertex)
	{
		return vertexSet.contains(vertex);
	}
	
	public boolean isVertexExist(Object vertexId)
	{
		return this.vertexMap.containsKey(vertexId);
	}
	
	public Vertex getVertex(Object vertexId)
	{
		return (Vertex)vertexMap.get(vertexId);
	}
	
	public boolean addVertex(Vertex vertex)
	{
		if (!vertexSet.contains(vertex))
		{
			vertexMap.put(vertex.getID(), vertex);
			vertexSet.add(vertex);
			
			return true;
		}else{
			return false;
		}
	}
	
	public boolean addVertex(Object id)
	{
		if ((id instanceof Comparable) == false)
		{
			this.isIDComparable = false;
		}
		
		if (!vertexMap.containsKey(id))
		{
			Vertex srcVertex = new Vertex(id);
			//srcVertex.setID(id);
			vertexMap.put(id, srcVertex);
			vertexSet.add(srcVertex);
			
			return true;
		}else{
			return false;
		}
	}
	
	public boolean isEdgeExist(Vertex v1, Vertex v2)
	{
		if (getEdge(v1, v2) == null){
			return false;
		}else{
			return true;
		}
	}
	
	public boolean isEdgeExist(Object fromId, Object toId)
	{
		if (isVertexExist(fromId) == false)
		{
			return false;
		}
		if (isVertexExist(toId) == false)
		{
			return false;
		}
		Vertex fromVertex = this.getVertex(fromId);
		Vertex toVertex = this.getVertex(toId);
		if (getEdge(fromVertex, toVertex) == null){
			return false;
		}else{
			return true;
		}
	}
	
	public Edge getEdge(Object fromVertex, Object toVertex)
	{
		Vertex v1 = this.getVertex(fromVertex);
		Vertex v2 = this.getVertex(toVertex);
		if ((v1 == null) || (v2 == null))
		{
			return null;
		}else{
			return this.getEdge(v1, v2);
		}
	}
	
	public Edge getEdge(Vertex fromVertex, Vertex toVertex)
	{
		if (!vertexSet.contains(fromVertex))
		{
			return null;
		}
		
		if (!vertexSet.contains(toVertex))
		{
			return null;
		}

		Iterator adjIter = fromVertex.getEdges();
		while (adjIter.hasNext()){	
			Edge edge = (Edge)adjIter.next();
			Vertex from = edge.getFirstVertex();
			Vertex to = edge.getSecondVertex();
			if ((from == fromVertex) && (to == toVertex)){
				return edge;
			}
			if ((to == fromVertex) && (from == toVertex)){
				return edge;
			}
		}
		return null;
	}

	
	public boolean addEdge(Vertex fromVertex, Vertex toVertex)
	{
		if (!vertexSet.contains(fromVertex)){
			vertexMap.put(fromVertex.getID(), fromVertex);
			vertexSet.add(fromVertex);
		}
		if (!vertexSet.contains(toVertex)){
			vertexMap.put(toVertex.getID(), toVertex);
			vertexSet.add(toVertex);
		}
		
		if (isSelfLoop == false)
		{
			if (fromVertex.equals(toVertex))
			{
				return false;
			}
		}
		
		Iterator adjIter = fromVertex.getEdges();
		while (adjIter.hasNext()){
			Edge edge = (Edge)adjIter.next();
			Vertex from = edge.getFirstVertex();
			Vertex to = edge.getSecondVertex();
			if ((from == fromVertex) && (to == toVertex)){
				return false;
			}
			if ((to == fromVertex) && (from == toVertex)){
				return false;
			}
		}
		
		Edge edge = new Edge();
		edge.setFirstVertex(fromVertex);
		edge.setSecondVertex(toVertex);
		fromVertex.addEdge(edge);
		toVertex.addEdge(edge);
		this.edgeSet.add(edge);
		
		return true;
	}

	public Iterator getEdgeIterator() 
	{
		return edgeSet.iterator();
	}
	
	public Iterator getVertexIterator()
	{
		return this.vertexSet.iterator();
	}
	
	public int getVertexNumber()
	{
		return this.vertexSet.size();
	}

	public int getEdgeNumber() 
	{
		return edgeSet.size();
	}
	
	public boolean isSelfLoopAllowed()
	{
		return this.isSelfLoop;
	}
	
	public void setSelfLoopAllowed(boolean flag)
	{
		this.isSelfLoop = flag;
	}


	public boolean isVertexIDComparable() 
	{
		return isIDComparable;
	}
}

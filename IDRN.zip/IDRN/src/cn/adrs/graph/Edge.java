package cn.adrs.graph;

import java.util.HashMap;


public class Edge
{
	private Vertex fromVertex;	
	private Vertex toVertex;
	
	public Edge()
	{

	}
	
	public Vertex getFirstVertex()
	{
		return fromVertex;
	}
	
	public void setFirstVertex(Vertex vertex)
	{
		fromVertex = vertex;
	}
	
	public void setSecondVertex(Vertex vertex) 
	{
		toVertex = vertex;
	}
	
	public Vertex getSecondVertex()
	{
		return toVertex;
	}
	
	public Vertex getAdjVertex(Vertex v)
	{
		if (v == fromVertex){
			return toVertex;
		}else if (v == toVertex){
			return fromVertex;
		}else{
			return null;
		}
	}
}

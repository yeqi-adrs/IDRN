package cn.adrs.graph;

import java.io.BufferedReader;


import java.io.*;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;


import cn.adrs.graph.*;

public class NaiveFileGraphReader 
{	
	public static void readUndirectedGraph(Graph graph, String infileName, int type)  throws IOException 
	{
		FileReader fr = new FileReader(infileName);
		BufferedReader reader = new BufferedReader(fr);
		String str;
		int counter = 0;
		while ((str = reader.readLine()) != null)
		{
			counter++;
			if (((counter % 10000) == 0))
			{
				System.out.println(counter);
			}
			
			if (str.startsWith("#"))
			{
				//skip the comments
				continue;
			}
			
			StringTokenizer token = new StringTokenizer(str, "\t");

			
			if (token.countTokens() >= 2)
			{
				String id1 = token.nextToken();
				String id2 = token.nextToken();
				Integer intId1 = Integer.parseInt(id1);
				Integer intId2 = Integer.parseInt(id2);
					
				graph.addEdge(intId1, intId2);
			}else if (token.countTokens() == 1){
				String id = token.nextToken();
				Integer intId = Integer.parseInt(id);
				graph.addVertex(intId);
			}else{
				System.out.println("Token error!");
			}
			
		}
		reader.close();
		fr.close();
	}
	
	public static Graph readUndirectedGraph(String infileName) throws IOException 
	{
		Graph graph = new Graph();
		FileReader fr = new FileReader(infileName);
		BufferedReader reader = new BufferedReader(fr);
		
		
		String str;
		int counter = 0;
		while ((str = reader.readLine()) != null)
		{
			if (str.startsWith("#"))
			{
				//skip the comments
				continue;
			}
			counter++;
			if ((counter % 1000000) == 0)
			{
				System.out.println(counter);
			}
			
			StringTokenizer token = new StringTokenizer(str);

			if (token.countTokens() >= 2)
			{
				String id1 = token.nextToken();
				String id2 = token.nextToken();
					
				Integer intId1 = Integer.parseInt(id1);
				Integer intId2 = Integer.parseInt(id2);
					
				graph.addEdge(intId1, intId2);
			}else if (token.countTokens() == 1){
				String id = token.nextToken();
				Integer intId = Integer.parseInt(id);
				
				graph.addVertex(intId);
			}else{
				System.out.println("Token error!");
			}
		}
		reader.close();
		
		int m = graph.getVertexNumber();
		int n = graph.getEdgeNumber();
		System.out.println("Vertex Num = " + m + "\t Edge num = " + n);
		
		return graph;
	}
}

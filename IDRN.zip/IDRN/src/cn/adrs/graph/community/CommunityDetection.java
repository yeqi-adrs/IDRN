package cn.adrs.graph.community;

import java.io.IOException;

import java.io.Writer;
import java.util.*;


public interface CommunityDetection 
{
	Collection<Community> findCommunities();
}

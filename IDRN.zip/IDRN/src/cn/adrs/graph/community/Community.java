package cn.adrs.graph.community;

import java.util.*;


import cn.adrs.graph.Edge;
import cn.adrs.graph.Graph;
import cn.adrs.graph.Vertex;

public class Community
{
	private Graph graph;
	private Set nodeSet;
	private int totalDegree;
	private int inDegree;
	private Comparable communityID;
	
	//this method is for a single node for a community
	public Community(Graph graph, Vertex node)
	{
		nodeSet = new HashSet();
		nodeSet.add(node);
		this.graph = graph;
		inDegree = 0;
		totalDegree = node.getDegree();
	}
	
	public Community(Graph graph, Set set)
	{
		this.graph = graph;
		this.nodeSet = set;
		
		Iterator iter = nodeSet.iterator();
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			int total = v.getDegree();
			int in = getIntraLinkNum(v);
			this.inDegree += in;
			this.totalDegree += total;
		}
		
	}
	
	public Community(Comparable ID, Graph graph, Set set)
	{
		this.communityID = ID;
		this.graph = graph;
		this.nodeSet = set;
		
		Iterator iter = nodeSet.iterator();
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			int total = v.getDegree();
			int in = getIntraLinkNum(v);
			this.inDegree += in;
			this.totalDegree += total;
		}
		
	}

	public Graph getBelongedGraph() 
	{
		return this.graph;
	}
	
	public boolean isContained(Vertex v)
	{
		return this.nodeSet.contains(v);
	}

	public int getVertexNum() 
	{
		return nodeSet.size();
	}

	public int getInDegrees() 
	{
		return this.inDegree;
	}

	public int getOutDegrees() 
	{
		int outDegree = totalDegree - inDegree;
		
		return outDegree;
	}

	public Set getVertexSet() 
	{
		return this.nodeSet;
	}

	public boolean insertVertex(Vertex v) 
	{
		if (this.nodeSet.contains(v))
		{
			return false;
		}else{
			int inLinks = this.getIntraLinkNum(v);
			int deltaInDegree = 2 * inLinks;
			this.inDegree += deltaInDegree;
			this.totalDegree += v.getDegree();
			return this.nodeSet.add(v);
		}
	}

	public boolean removeVertex(Vertex v) 
	{
		if (this.nodeSet.contains(v))
		{
			int inLinks = this.getIntraLinkNum(v);
			int deltaInDegree = 2 * inLinks;
			this.inDegree -= deltaInDegree;
			this.totalDegree -= v.getDegree();

			if (totalDegree < 0)
			{
				throw new IllegalArgumentException("The community total degree can never be negative.");
			}
			if (inDegree < 0)
			{
				System.out.println(inDegree + "\t" + totalDegree);
				throw new IllegalArgumentException("The community in degree can never be negative.");
			}
			return this.nodeSet.remove(v);
		}else{
			return false;
		}
	}
	
	public Iterator getVertexIterator()
	{
		return this.nodeSet.iterator();
	}
	
	public int getTotalDegrees()
	{
		return this.totalDegree;
	}
	
	public int getIntraLinkNum(Vertex v)
	{
		int counter = 0;
		Iterator iter = v.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adj = edge.getAdjVertex(v);
			if (this.nodeSet.contains(adj))
			{
				counter++;
			}
		}
		return counter;
	}
	
	private void addIntraLinks(Vertex v, Graph copyGraph)
	{
		Iterator iter = v.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adj = edge.getAdjVertex(v);
			if (this.nodeSet.contains(adj))
			{
				copyGraph.addEdge(v.getID(), adj.getID());
			}
		}
	}
	
	private void addIntraLinks(Set edgeSet, Vertex v)
	{
		Iterator iter = v.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adj = edge.getAdjVertex(v);
			if (this.nodeSet.contains(adj))
			{
				edgeSet.add(edge);
			}
		}
	}
	
	public Set getIntraLinkSet()
	{
		HashSet edgeSet = new HashSet();
		
		Iterator iter = this.nodeSet.iterator();
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			addIntraLinks(edgeSet, v);
		}
		
		return edgeSet;
	}
	
	public int getIntraLinkNum()
	{
		return this.inDegree / 2;
	}

	public int compareTo(Object arg0) 
	{
		Community community = (Community)arg0;
		
		if ((this.communityID == null) || (community.communityID == null))
			return 0;
		
		return this.communityID.compareTo(community.communityID);
	}

	public Comparable getID() 
	{
		return this.communityID;
	}
	
	public void setID(Comparable ID)
	{
		this.communityID = ID;
	}
}

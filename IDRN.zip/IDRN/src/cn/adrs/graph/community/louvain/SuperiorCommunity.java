package cn.adrs.graph.community.louvain;

import java.util.*;

import cn.adrs.graph.*;

public class SuperiorCommunity 
{
	private long communityID;
	private SuperiorGraph graph;
	private Set nodeSet;
	private double totalWeightedDegree;
	private double inWeightedDegree;
	
	public SuperiorCommunity(SuperiorGraph graph, Vertex v)
	{
		this.graph = graph;
		this.nodeSet = new HashSet();
		
		this.nodeSet.add(v);
		this.inWeightedDegree = graph.getWeightedSelfloop(v);
		this.totalWeightedDegree = graph.getWeighedDegree(v);		
	}
	
	public void setCommunityID(long id)
	{
		this.communityID = id;
	}
	
	public long getCommunityID()
	{
		return this.communityID;
	}
	
	public double getLinkWeights(Vertex v) 
	{
		double sum = 0;
		Iterator iter = v.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adj = edge.getAdjVertex(v);
			
			if (adj != v)
			{
				if (this.nodeSet.contains(adj))
				{
					double w = graph.getWeight(edge);
					sum += w;
				}
			}
		}
		
		return sum;
	}

	public double getIntraDegree() 
	{
		return inWeightedDegree;
	}

	public double getOutDegreeWeight() 
	{
		return totalWeightedDegree - this.inWeightedDegree;
	}

	public double getTotalDegreeWeight() 
	{
		return totalWeightedDegree;
	}

	public boolean isContained(Vertex v) 
	{
		return this.nodeSet.contains(v);
	}

	public boolean insert(Vertex v) 
	{
		double selfloopWeight = this.graph.getWeightedSelfloop(v);
		double inLinks = this.getLinkWeights(v);
		
		this.totalWeightedDegree += this.graph.getWeighedDegree(v);
		this.inWeightedDegree += 2 * inLinks + selfloopWeight;
		
		return nodeSet.add(v);
	}
	
	public boolean remove(Vertex v) 
	{
		double selfloopWeight = this.graph.getWeightedSelfloop(v);
		double inLinks = this.getLinkWeights(v);
		
		this.totalWeightedDegree -= this.graph.getWeighedDegree(v);
		this.inWeightedDegree -= 2 * inLinks + selfloopWeight;
		
		return this.nodeSet.remove(v);
	}
	
	public double getModularityGain(Vertex v)
	{
		double totc = this.totalWeightedDegree;
		double degc = this.graph.getWeighedDegree(v);
		double m2   = this.graph.getTotalWeight();
		double dnc  = (double)getLinkWeights(v);
		  
		return (dnc - totc*degc/m2) ;
	}
}

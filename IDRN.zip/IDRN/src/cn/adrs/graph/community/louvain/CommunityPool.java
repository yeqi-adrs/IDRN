package cn.adrs.graph.community.louvain;

import java.util.*;

import cn.adrs.graph.*;

public class CommunityPool
{
	private SuperiorGraph graph;
	private int passNum;
	private double minModularity;
	private Map nodeCommunityMap;
	
	public CommunityPool(SuperiorGraph graph, int nbp, double minm)
	{
		this.graph = graph;
		this.passNum = nbp;
		this.minModularity = minm;
		nodeCommunityMap = new HashMap();
		
		Iterator iter = graph.getVertexIterator();
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			SuperiorCommunity community = new SuperiorCommunity(graph, v);
			this.nodeCommunityMap.put(v, community);
		}
	}

	public SuperiorGraph getCommunityGraph() 
	{
		SuperiorGraph superGraph = new SuperiorGraph(true);
		Iterator iter = this.nodeCommunityMap.values().iterator();
		while (iter.hasNext())
		{
			SuperiorCommunity community = (SuperiorCommunity)iter.next();
			long id = community.getCommunityID();
			superGraph.addVertex(id);
		}
		
		Iterator edgeIter = this.graph.getEdgeIterator();
		while (edgeIter.hasNext())
		{
			Edge edge = (Edge)edgeIter.next();
			Vertex v1 = edge.getFirstVertex();
			Vertex v2 = edge.getSecondVertex();
			double weight = this.graph.getWeight(edge);
			
			SuperiorCommunity comm1 = this.getCommunity(v1);
			SuperiorCommunity comm2 = this.getCommunity(v2);
			long commID1 = comm1.getCommunityID();
			long commID2 = comm2.getCommunityID();
			
			superGraph.addEdge(commID1, commID2);
			Edge commEdge = superGraph.getEdge(commID1, commID2);
			superGraph.addEdgeWeight(commEdge, weight);	
		}
		
		return superGraph;
	}

	public double getModularity() 
	{	
		double m2 = this.graph.getTotalWeight();
		double Q = 0;
		
		Set communitySet = this.getCommunitySet();
		
		Iterator iter = communitySet.iterator();
		while (iter.hasNext())
		{
			SuperiorCommunity community = (SuperiorCommunity)iter.next();
			double in = community.getIntraDegree();
			double total = community.getTotalDegreeWeight();
			Q += in / m2  - (total / m2) * (total / m2);
		}
		
		return Q;
	}
	
	public Set getNeighborCommunities(Vertex v)
	{
		Set communitySet = new HashSet();
		
		Iterator edgeIter = v.getEdges();
		while (edgeIter.hasNext())
		{
			Edge edge = (Edge)edgeIter.next();
			Vertex adj = edge.getAdjVertex(v);
			SuperiorCommunity adjCom = this.getCommunity(adj);
			communitySet.add(adjCom);
		}
		
		return communitySet;
	}
	
	public void initCommunityIDs()
	{
		long id = 0;
		Set communitySet = this.getCommunitySet();
		Iterator iter = communitySet.iterator();
		while (iter.hasNext())
		{
			SuperiorCommunity comm = (SuperiorCommunity)iter.next();
			comm.setCommunityID(id);
			id++;
		}
	}
	
	public SuperiorCommunity getCommunity(Vertex v)
	{
		SuperiorCommunity community = (SuperiorCommunity)this.nodeCommunityMap.get(v);
		
		return community;
	}

	public double oneLevel() 
	{
		boolean improvement = false;
		int numberPassDone = 0;
		double newModularity = this.getModularity();
		double currentmodularity = newModularity;
		double delta = 0;
		
		do {
			currentmodularity = newModularity;
			improvement = false;
			numberPassDone++;
			
			Iterator iter = graph.getVertexIterator();
			while (iter.hasNext())
			{
				Vertex v = (Vertex)iter.next();
				SuperiorCommunity oldCommunity = getCommunity(v);
				Set neighborComms = this.getNeighborCommunities(v);
				removeCommunity(v);
				
				SuperiorCommunity bestCommunity = oldCommunity;
			    double bestIncrease = 0.0;
			    Iterator neighborIter = neighborComms.iterator();
			    while (neighborIter.hasNext())
			    {
			    	SuperiorCommunity neighborComm = (SuperiorCommunity)neighborIter.next();
			    	double increase = neighborComm.getModularityGain(v);
			    	if (increase > bestIncrease)
			    	{
			    		bestIncrease = increase;
			    		bestCommunity = neighborComm;
			    	}
			    }
			    
			    addToCommunity(v, bestCommunity);
			    if (bestCommunity != oldCommunity)
			        improvement=true;
			}
			
			newModularity = this.getModularity();
			
			delta = newModularity - currentmodularity;
		} while (improvement &&  delta > minModularity && numberPassDone != passNum);

		initCommunityIDs();
		
		return newModularity;
	}
	
	public Map getVertexCommunityMaper()
	{	
		return nodeCommunityMap;
	}
	
	public SuperiorCommunity removeCommunity(Vertex v)
	{
		SuperiorCommunity oldCommunity = getCommunity(v);
		oldCommunity.remove(v);
		this.nodeCommunityMap.remove(v);
		
		return oldCommunity;
	}
	
	public Set getCommunitySet()
	{
		Set communitySet = new HashSet();
		
		Iterator iter = this.nodeCommunityMap.values().iterator();
		while (iter.hasNext())
		{
			SuperiorCommunity com = (SuperiorCommunity)iter.next();
			communitySet.add(com);
		}
		
		return communitySet;
	}
	
	public void addToCommunity(Vertex v, SuperiorCommunity community)
	{
		
		if (nodeCommunityMap.containsKey(v))
		{
			SuperiorCommunity oldCommunity = this.getCommunity(v);
			oldCommunity.remove(v);
		}
		community.insert(v);
		nodeCommunityMap.put(v, community);
	}
}

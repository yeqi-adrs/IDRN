package cn.adrs.graph.community.louvain;

import java.util.*;



import cn.adrs.graph.*;

public class SuperiorGraph extends Graph
{
	private HashMap edgeWeightMap;
	private boolean isWeighted;
	private double totalWeight = Double.NaN;
	
	public SuperiorGraph(boolean weighted)
	{
		this.setSelfLoopAllowed(true);
		
		this.isWeighted = weighted;
		if (isWeighted)
		{
			this.edgeWeightMap = new HashMap();
		} else {
			this.edgeWeightMap = null;
		}
		
		totalWeight = Double.NaN;
	}
	
	public SuperiorGraph(boolean weighted, boolean isSelfLoop)
	{
		this.setSelfLoopAllowed(isSelfLoop);
		
		this.isWeighted = weighted;
		if (isWeighted)
		{
			this.edgeWeightMap = new HashMap();
		} else {
			this.edgeWeightMap = null;
		}
		
		totalWeight = Double.NaN;
	}
	
	public void addEdgeWeight(Edge edge, double weight)
	{
		if (edgeWeightMap.containsKey(edge) == false)
		{
			edgeWeightMap.put(edge, weight);
		} else {
			double value = (Double)edgeWeightMap.get(edge);
			value += weight;
			edgeWeightMap.put(edge, value);
		}
	}
	
	public void setEdgeWeight(Edge edge, double weight)
	{
		this.edgeWeightMap.put(edge, weight);
	}
	
	public double getWeighedDegree(Vertex v)
	{
		if (edgeWeightMap == null)
		{
			return v.getDegree();
		} else {
			double result = 0;
			
			Iterator iter = v.getEdges();
			
			while (iter.hasNext())
			{
				Edge edge = (Edge)iter.next();
				
				double weight = this.getWeight(edge);
				result += weight;
			}
			
			return result;
		}
	}
	
	public boolean isSelfloop(Edge edge)
	{
		Vertex v1 = edge.getFirstVertex();
		Vertex v2 = edge.getSecondVertex();
		
		if (v1 == v2)
		{
			return true;
		}else{
			return false;
		}
	}
	
	public double getWeightedSelfloop(Vertex v)
	{
		Iterator iter = v.getEdges();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adj = edge.getAdjVertex(v);
			if (adj == v)
			{
				if (this.edgeWeightMap.containsKey(edge))
				{
					return  2 * (Double)this.edgeWeightMap.get(edge);
				}else{
					return 2.0;
				}
			}
		}
		
		return 0;
	}
	
	public double getWeight(Edge edge)
	{
		if (this.edgeWeightMap == null) 
		{
			return 1.0;
		}else {
			return (Double)this.edgeWeightMap.get(edge);
		}	
	}
	
	public void initTotalWeight()
	{
		if (this.edgeWeightMap == null)
		{
			this.totalWeight = 2 * this.getEdgeNumber();
		} 
		else 
		{
			double sum = 0;
			
			Iterator iter = this.getEdgeIterator();
			while (iter.hasNext())
			{
				Edge edge = (Edge)iter.next();
				double w = (Double)this.edgeWeightMap.get(edge);
				sum += 2 * w;
			}
			
			this.totalWeight = sum;
		}
	}
	
	public double getTotalWeight()
	{
		if (Double.isNaN(this.totalWeight))
		{
			initTotalWeight();
		}
		
		return this.totalWeight;
	}
}

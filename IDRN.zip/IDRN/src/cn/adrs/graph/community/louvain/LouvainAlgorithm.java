package cn.adrs.graph.community.louvain;

import java.util.*;
import java.io.*;

import cn.adrs.graph.*;
import cn.adrs.graph.community.*;

/**
 * This is a java implement of Louvain algorithm for convenience of experiments.
 * There is a c++ version implemented by the authors: https://sites.google.com/site/findcommunities/
 * 
 * The reference of the article is as the following, 
 * @article{Blondel2008,
    journal = {Journal of Statistical Mechanics: Theory and Experiment},
    month = {9 October},
    author = {Blondel, Vincent D. and Guillaume, Jean-Loup and Lambiotte, Renaud and Lefebvre, Etienne},
    title = {Fast unfolding of communities in large networks},
    pages ={10008},
    year = {2008}
   }
 *
 */

public class LouvainAlgorithm implements CommunityDetection
{
	private Graph graph;
	private SuperiorGraph weightedGraph;
	private int passNumber = 0;
	private double eplosion = 0.000001;
	private boolean justFirstLevel = false;
	private int maxLevelNum = 20;
	
	public LouvainAlgorithm(Graph graph)
	{
		this(graph, -1, 0.0001, false);
	}
	
	public LouvainAlgorithm(Graph graph, int passNumber, double minModulairy, boolean isOneLevel)
	{
		copyGraph(graph);
		this.graph = graph;
		this.passNumber = passNumber;
		this.eplosion = minModulairy;
		this.justFirstLevel = isOneLevel;
	}
	
	private void copyGraph(Graph graph)
	{
		weightedGraph = new SuperiorGraph(false);
		
		Iterator iter = graph.getVertexIterator();
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			
			this.weightedGraph.addVertex(v.getID());
		}
		
		iter = graph.getEdgeIterator();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex v1 = edge.getFirstVertex();
			Vertex v2 = edge.getSecondVertex();
			
			this.weightedGraph.addEdge(v1.getID(), v2.getID());
		}
	}
	
	public Collection findCommunities()
	{
		CommunityPool communityPool = new CommunityPool(this.weightedGraph, passNumber, eplosion);
		
		double oldModularity = communityPool.getModularity();
		
		double newModularity = communityPool.oneLevel();
		
		CommunityBelonger mapper;
	
		mapper = new CommunityBelonger(weightedGraph);
		
		
		SuperiorGraph g = communityPool.getCommunityGraph();
		mapper.initCommunityMap(communityPool.getVertexCommunityMaper());
		
		int level=0;
		while((newModularity - oldModularity > eplosion) && (justFirstLevel == false)) 
		{
			oldModularity = newModularity;
			
			communityPool = new CommunityPool(g, passNumber, eplosion);

			newModularity = communityPool.oneLevel();
			
			level++;
			
			g = communityPool.getCommunityGraph();
			mapper.highLevelCommunityMap(communityPool.getVertexCommunityMaper());
			
			if (level >= maxLevelNum)
			{
				break;
			}
		}
		
		Collection weightedCommunities = mapper.getCommunities();
		return getGraphCommunities(weightedCommunities);
	}
	
	public Collection getGraphCommunities(Collection weightedGraphCommunities)
	{
		if (graph == null)
		{
			return weightedGraphCommunities;
		} 
		else 
		{
			Collection collection = new ArrayList();
			Iterator iter = weightedGraphCommunities.iterator();
			
			while (iter.hasNext())
			{
				Set nodeSet = new HashSet();
				
				Community weightedComm = (Community)iter.next();
				Iterator nodeIter = weightedComm.getVertexIterator();
				while (nodeIter.hasNext())
				{
					Vertex  weightedNode = (Vertex)nodeIter.next();
					Vertex node = graph.getVertex(weightedNode.getID());
					
					nodeSet.add(node);
				}
				
				Community community = new Community(graph, nodeSet);
				collection.add(community);
			}
			
			return collection;
		}
	}
}
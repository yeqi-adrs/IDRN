package cn.adrs.graph.community.louvain;

import java.io.*;
import java.util.*;


import cn.adrs.graph.*;
import cn.adrs.graph.community.*;

public class CommunityBelonger 
{
	private HashMap nodeCommunityIDMap = new HashMap();
	private HashMap nodeSetMap = new HashMap();
	private SuperiorGraph graph;
	
	public CommunityBelonger(SuperiorGraph  graph)
	{
		this.graph = graph;
	}
	
	public void initCommunityMap(Map map)
	{
		Iterator iter = map.keySet().iterator();
		while (iter.hasNext())
		{
				
			Vertex v = (Vertex)iter.next();
			SuperiorCommunity comm = (SuperiorCommunity)map.get(v);
			long communityID = comm.getCommunityID();
			nodeCommunityIDMap.put(v, communityID);
		}
			
		updateNodeSets();
	}
	
	public Collection getCommunities()
	{
		List communities = new ArrayList();
		
		Iterator iter = nodeSetMap.keySet().iterator();
		while (iter.hasNext())
		{
			Object id = iter.next();
			Set set = (Set)nodeSetMap.get(id);
			Community community = new Community(graph, set);
			communities.add(community);
		}
		
		return communities;
	}
	
	public void highLevelCommunityMap(Map map)
	{
		Iterator iter = map.keySet().iterator();
			
		while (iter.hasNext())
		{
			Vertex v = (Vertex)iter.next();
			long oldID = (Long)v.getID();
				
			SuperiorCommunity comm = (SuperiorCommunity)map.get(v);
			long communityID = comm.getCommunityID();
				
			Set rawNodeSet = (Set)nodeSetMap.get(oldID);
			Iterator nodeIter = rawNodeSet.iterator();
			while (nodeIter.hasNext())
			{
				Object obj = nodeIter.next();
				this.nodeCommunityIDMap.put(obj, communityID);
			}
		}
			
		updateNodeSets();
	}
	
	public void updateNodeSets()
	{
		nodeSetMap = new HashMap();
		
		Iterator iter = nodeCommunityIDMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry entry = (Map.Entry)iter.next();
			Object v = entry.getKey();
			Object communityID = entry.getValue();
			
			if (nodeSetMap.containsKey(communityID) == false)
			{
				Set nodeSet = new HashSet();
				nodeSet.add(v);
				nodeSetMap.put(communityID, nodeSet);
			} else {
				Set nodeSet = (Set)nodeSetMap.get(communityID);
				nodeSet.add(v);
			}
		}
	}
}

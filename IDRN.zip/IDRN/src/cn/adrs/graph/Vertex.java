package cn.adrs.graph;

import java.util.*;


public class Vertex 
{
	private Object id;
	private List adjEdge;
	
	public Vertex()
	{
		adjEdge = new ArrayList();
	}
	
	public Vertex(Object id)
	{
		this();
		this.id = id;
	}
	
	public void setID(Object id)
	{
		this.id = id;
	}
	
	public Object getID()
	{
		return this.id;
	}
	
	public boolean addEdge(Edge edge)
	{
		return adjEdge.add(edge);
	}
	
	public boolean removeEdge(Edge edge)
	{
		return adjEdge.remove(edge);
	}
	
	public Iterator getEdges()
	{
		return adjEdge.iterator();
	}
	
	public int getDegree()
	{
		return adjEdge.size();
	}
	
	public boolean isAdjustTo(Vertex v)
	{
		Iterator iter = adjEdge.iterator();
		while (iter.hasNext())
		{
			Edge edge = (Edge)iter.next();
			Vertex adjVertex = edge.getAdjVertex(this);
			if (adjVertex == v)
				return true;
		}
		return false;
	}
	
	public String toString()
	{
		return this.id.toString();
	}
}

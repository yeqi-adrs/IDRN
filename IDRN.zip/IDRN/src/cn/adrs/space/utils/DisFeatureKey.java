package cn.adrs.space.utils;


public class DisFeatureKey 
{
	public long featureID;
	public int value;
	
	public DisFeatureKey(long feature, int value)
	{
		this.featureID = feature;
		this.value = value;
	}
	
	public boolean equals(Object obj)
	{
		DisFeatureKey key = (DisFeatureKey)obj;
		
		if ((this.featureID == key.featureID) && (this.value == key.value))
		{
			return true;
		}
		
		return false;
	}
	
	public int hashCode()
	{
		int idHashCode = (int)featureID;//Integer.hashCode((int)featureID);
		int valueHashCode = value;//Integer.hashCode(value);
		
		return idHashCode * 13 + valueHashCode;
	}
}

package cn.adrs.space.utils;

public class DisFeatureClassKey 
{
	public long featureID;
	public int value;
	public int classLabel;
	
	public DisFeatureClassKey(long feature, int value, int label)
	{
		this.featureID = feature;
		this.value = value;
		this.classLabel = label;
	}
	
	public boolean equals(Object obj)
	{
		DisFeatureClassKey key = (DisFeatureClassKey)obj;
		
		if ((this.featureID == key.featureID) && 
				(this.value == key.value) && (this.classLabel == key.classLabel))
		{
			return true;
		}
		
		return false;
	}
	
	public int hashCode()
	{
		int idHashCode = (int)featureID;//Integer.hashCode((int)featureID);
		int valueHashCode = value;//Integer.hashCode(value);
		
		
		return idHashCode * 13 + valueHashCode + this.classLabel;
	}
}

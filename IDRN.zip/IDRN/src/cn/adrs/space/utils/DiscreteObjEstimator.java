package cn.adrs.space.utils;

import java.io.*;
import java.util.*;

public class DiscreteObjEstimator 
{
	private HashMap timesMap = new HashMap();
	private double totalSum;
	
	public void addValue(Object id, double weight)
	{
		if (timesMap.containsKey(id))
		{
			double w = (Double)timesMap.get(id);
			w += weight;
			timesMap.put(id, w);
		}else{
			timesMap.put(id, weight);
		}
		totalSum += weight;
	}
	
	public int getSize()
	{
		return this.timesMap.size();
	}
	
	public void normalizeToProbability()
	{
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Comparable, Double> entry = (Map.Entry)iter.next();
			Comparable key = entry.getKey();
			double value = entry.getValue();
			
			double prob = value / this.totalSum;
			
			entry.setValue(prob);
		}
		
		this.totalSum = 1.0;
	}
	
	public double getValue(Object id)
	{
		if (timesMap.containsKey(id))
		{
			double w = (Double)timesMap.get(id);
			return w;
		}else{
			return 0;
		}
	}
	
	public void scale(double factor)
	{
		 Iterator iter = this.timesMap.entrySet().iterator();
		 while (iter.hasNext())
		 {
			 Map.Entry<Object, Double> entry = (Map.Entry<Object, Double>)iter.next();
			 
			 Object obj = entry.getKey();
			 double value = entry.getValue();
			 
			 value *= factor;
			 this.timesMap.put(obj, value);
		 }
	}
	
	public double getProbability(Object id)
	{
		double w = (Double)timesMap.get(id);
		return w / totalSum;
	}
	
	public double getTotalSum()
	{
		return totalSum;
	}
	
	public Iterator<Map.Entry<Object, Double>>  getEntries()
	{
		return this.timesMap.entrySet().iterator();
	}
	
	public double getMaxValue()
	{
		double max = Double.NEGATIVE_INFINITY;
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double v = getValue(key);
			if (v >= max)
			{
				max = v;
			}
		}
		return max;
	}
	
	public double getMinValue()
	{
		double min = Double.POSITIVE_INFINITY;
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double v = getValue(key);
			if (v <= min)
			{
				min = v;
			}
		}
		
		return min;
	}
	
	
	public Object getMinValueObj()
	{
		double min = Double.POSITIVE_INFINITY;
		Object obj = null;
		
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double v = getValue(key);
			if (v <= min)
			{
				min = v;
				obj = entry.getKey();
			}
		}
		
		if (obj == null)
		{
			System.out.println(min);
			System.out.println("This can never happen");
		}
		
		return obj;
	}
	
	public Object getMaxValueObj()
	{
		double max = Double.NEGATIVE_INFINITY;
		Object obj = null;
		
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double v = getValue(key);
			if (v >= max)
			{
				obj = key;
				max = v;
			}
		}
		
		if (obj == null)
		{
			System.out.println(max);
			System.out.println("This can never happen");
		}
		
		return obj;
	}
	
	public Entry getMaxValueEntry()
	{
		double max = Double.NEGATIVE_INFINITY;
		Object obj = null;
		//ArrayList randMaxList = new ArrayList();
		
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double v = getValue(key);
			if (v >= max)
			{
				obj = key;
				max = v;
			}
		}
		
		if (obj == null)
		{
			System.out.println(max);
			System.out.println("This can never happen");
		}
		
		Entry entry = new Entry(obj, max);
		return entry;
	}
	
	public double getEntropy()
	{
		double sum = 0;
		
		double []p = this.getProbabilities();
		for (int i = 0; i < p.length; i++)
		{
			sum -= p[i] * Math.log(p[i]); 
		}
		
		return sum;
	}
	
	
	public double []getProbabilities()
	{
		double []result = new double[timesMap.entrySet().size()];
		
		int i = 0;
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double p = getProbability(key);
			result[i++] = p;
		}
		
		return result;
	}
	
	
	public void printProbabilities(Writer writer) throws IOException
	{
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double p = getProbability(key);
			writer.write(key + "\t" + p + "\n");
		}
	}
	
	public void printProbabilities()
	{
		Iterator iter = timesMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<Object, Double> entry = (Map.Entry)iter.next();
			Object key = entry.getKey();
			double p = getProbability(key);
			System.out.println(key + "\t" + p);
		}
	}
	
	public class Entry
	{
		public Object obj;
		public double value;
		
		public Entry(Object obj, double value)
		{
			this.obj = obj;
			this.value = value;
		}
	}
}

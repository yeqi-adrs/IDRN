package cn.adrs.space.utils;


public class IDWeight implements Comparable
{
	public Comparable id;
	public double weight;
	
	public IDWeight(Comparable id, double weight)
	{
		this.id = id;
		this.weight = weight;
	}
	
	public int compareTo(Object arg0) 
	{
		IDWeight another = (IDWeight)arg0;
		
		return id.compareTo(another.id);
	}
}

package cn.adrs.space.utils;

import java.util.Comparator;

public class IDWeightComparator implements Comparator
{
	public int compare(Object a, Object b)
	{
		IDWeight idWeight1 = (IDWeight)a;
		IDWeight idWeight2 = (IDWeight)b;
		
		if (idWeight1.weight > idWeight2.weight)
		{
			return 1;
		} 
		else if (idWeight1.weight < idWeight2.weight)
		{
			return -1;
		}
		
		return 0;
	}
}

package cn.adrs.space.vectorspace.table;

import java.util.Iterator;
import java.util.Set;

import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.Feature;

public interface DataTable 
{
	DataPoint getDataPoint(int i);
    
    Iterator getDataPoints();
    
    void addDataPoint(DataPoint instance);
    
    int getDataPointNum();
    
    void addFeatureID(Feature featureNode);
    
    void randomize();
    
    Set getFeatureIDSet();
    
    boolean isDense();
}

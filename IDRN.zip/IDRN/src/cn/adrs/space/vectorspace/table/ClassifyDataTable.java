package cn.adrs.space.vectorspace.table;

import java.util.*;

import cn.adrs.space.utils.DiscreteObjEstimator;


public interface ClassifyDataTable extends DataTable
{   
	//the label is enumerable
    Set getClassLabelSet();
    
    public double[] getColumn(int index);
    
    long getMaxFeatureID();
}

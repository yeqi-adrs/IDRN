package cn.adrs.space.vectorspace.table;

import java.util.*;

import cn.adrs.space.utils.DiscreteObjEstimator;
import cn.adrs.space.vectorspace.DataPoint;
import cn.adrs.space.vectorspace.DataPointImpl;
import cn.adrs.space.vectorspace.Feature;

public class ClassifyDataTableImpl implements ClassifyDataTable
{
    /** array of sparse feature nodes */
    public ArrayList<DataPoint> instancesList; 
    public Set featureIndexSet;
    private Set classLabelSet;
    private boolean isInstanceDense = false;
    private long maxFeatureIndex = Integer.MIN_VALUE;
    
    public ClassifyDataTableImpl()
    {
    	this.instancesList = new ArrayList();
    	this.featureIndexSet = new HashSet();
    	this.classLabelSet = new HashSet();
    }
    
    public DataPoint getDataPoint(int i)
    {
    	return this.instancesList.get(i);
    }
    
    public int getDataPointNum()
    {
    	return this.instancesList.size();
    }
    
    public void addDataPoint(DataPoint dataPoint)
    {
    	this.instancesList.add(dataPoint);
    	
    	//record the feature id
    	Iterator iter = dataPoint.getFeatures();
		while (iter.hasNext())
		{
			Feature featureNode = (Feature)iter.next();
    		this.addFeatureID(featureNode);
    	}
    	
		//record the class label
    	if (dataPoint.isLabeled())
    	{
    		if (dataPoint.isMultiLabel())
    		{
    			Iterator labelIter = dataPoint.getLabelSet().iterator();
    			while (labelIter.hasNext())
    			{
    				this.classLabelSet.add(labelIter.next());
    			}
    		} else {
    			this.classLabelSet.add(dataPoint.getClassLabel());
    		}
    	}
    }

    
    public void addFeatureID(Feature featureNode)
    {
    	long id = featureNode.getFeatureID();
    	this.featureIndexSet.add(id);
    	if (id > this.maxFeatureIndex)
    	{
    		this.maxFeatureIndex = id;
    	}
    }
    
    public void randomize()
    {
    	Collections.shuffle(this.instancesList);
    }
    
    public Set getFeatureIDSet()
    {
    	return this.featureIndexSet;
    }
    
    public Set getClassLabelSet()
    {
    	return this.classLabelSet;
    }
    

	@Override
	public Iterator getDataPoints() 
	{
		return this.instancesList.iterator();
	}

	@Override
	public boolean isDense() 
	{
		return isInstanceDense;
	}
	
	private boolean checkIndexInt()
	{
		Iterator iter = this.featureIndexSet.iterator();
		while (iter.hasNext())
		{
			Comparable index = (Comparable)iter.next();
			
			if ((index instanceof Number) == false)
			{
				return false;
			}
		}
		
		return true;
	}

	@Override
	public double[] getColumn(int index) 
	{
		ArrayList list = new ArrayList();
		for (int i = 0; i < this.getDataPointNum(); i++)
		{
			DataPoint point = this.getDataPoint(i);
			
			for (int j = 0; j < point.getFeatureNum(); j++)
			{
				Feature feature = point.getFeature(i);
				
				if (feature.getFeatureID() == index)
				{
					list.add(feature.getValue());
				}
			}
		}
		
		double result[] = new double[list.size()];
		
		for (int i = 0; i < list.size(); i++)
		{
			result[i] = (Double)list.get(i);
		}
		
		return result;
	}

	public long getMaxFeatureID() 
	{
		return (long)this.maxFeatureIndex;
	}
}

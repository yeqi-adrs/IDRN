package cn.adrs.space.vectorspace;

import java.util.*;

public class DataPointImpl implements DataPoint 
{
	protected Object id= null;
	protected boolean isLabeled = false;
	protected List<Feature> features; 
	
	protected Double label;//for single label data point
	
	private boolean isMultiLabel;
	private HashSet<Integer> labeSet; // for multi-label data point
	
	
	public DataPointImpl()
	{
		features = new ArrayList<Feature>();
		isLabeled = false;
	}	
	
	public DataPointImpl(double[] featureValues)
	{
		this.features = new ArrayList();
		
		for (int i = 0; i < featureValues.length; i++)
		{
			double value = featureValues[i];
			Feature feature = new Feature(i, value);
			
			features.add(feature);
		}
		
		this.isLabeled = false;
		
		sortIndex();
	}
	
	public DataPointImpl(Feature[] features)
	{
		this.isLabeled = false;
		this.features = new ArrayList(); 

		for (int i = 0; i < features.length; i++)
		{
			Feature node = features[i];
			this.features.add(node);
		}
		
		sortIndex();
	}

	@Override
	public void setID(Object id)
	{
		this.id = id;
	}
	
	@Override
	public Object getID()
	{
		return this.id;
	}
	
	public DataPointImpl(List<Feature> features)
	{
		this.isLabeled = false;
		this.features = features;
		sortIndex();
	}
	
	public DataPointImpl(Feature[] features, double label)
	{
		this.label = label;
		this.features = new ArrayList(); 
		
		for (int i = 0; i < features.length; i++)
		{
			Feature node = features[i];
			this.features.add(node);
		}
		
		this.isLabeled = true;
		sortIndex();
	}
	
	public DataPointImpl(List<Feature> features, double label)
	{
		this.label = label;
		this.features = features;
		
		this.isLabeled = true;
		sortIndex();
		isMultiLabel = false;
	}
	
	@Override
	public int getClassLabel()
	{
		return label.intValue();
	}

	@Override
	public double getFloatLabel()
	{
		return label;
	}
	

	@Override
	public boolean isLabeled()
	{
		return this.isLabeled;
	}
	
	@Override
	public void setLabel(int label)
	{
		this.isLabeled = true;
		
		this.label = (double)label;
		this.isMultiLabel = false;
	}
	

	@Override
	public void addFeature(Feature featureNode)
	{
		this.features.add(featureNode);
		
		sortIndex();
	}
	
	@Override
	public int getFeatureNum()
	{
		return this.features.size();
	}
	
	@Override
	public Iterator getFeatures()
	{
		return this.features.iterator();
	}
	
	@Override
	public Feature getFeature(int i)
	{
		return this.features.get(i);
	}
	

	@Override
	public void sortIndex()
	{
		Collections.sort(features);	
	}
	
	@Override
	public void addLabel(int label)
	{
		if (this.labeSet == null)
		{
			this.labeSet = new HashSet();
		}
		this.labeSet.add(label);
		this.isLabeled = true;
		isMultiLabel = true;
	}
	

	@Override
	public boolean isMultiLabel()
	{
		return isMultiLabel;
	}
	
	/* (non-Javadoc)
	 * @see cn.yeqi.space.vectorspace.DataPoint#getLabelSet()
	 */
	@Override
	public Set<Integer> getLabelSet()
	{
		return this.labeSet;
	}
	
	/* (non-Javadoc)
	 * @see cn.yeqi.space.vectorspace.DataPoint#toString()
	 */
	@Override
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		
		for (int i = 0; i < this.getFeatureNum(); i++)
		{
			Feature feature = this.getFeature(i);
			
			long id = feature.getFeatureID();
			double value = feature.getValue();
			
			buf.append(id + ":" + value + "\t");
		}
		
		buf.append(label);
		
		return buf.toString();
	}
}

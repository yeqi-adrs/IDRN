package cn.adrs.space.vectorspace;

public class Feature implements Comparable
{
	private long featureID;
	private Double value;
	
	public Feature(long index, double value) 
    {
        this.featureID = index;
        this.value = value;
    }
    
    public long getFeatureID()
    {
    	return featureID;
    }
    
    @Override
	public int compareTo(Object arg0) 
	{
		Feature another = (Feature)arg0;
		
		if (this.featureID == another.featureID)
		{
			return 0;
		} else if (this.featureID > another.featureID){
			return 1;
		} else {
			return -1;
		}
	}
    
    public int getIntValue()
    {
    	return this.value.intValue();
    }
    
    public Double getValue()
    {
    	return this.value;
    }
    
    public String toString() 
    {
        return "Feature(idx=" + featureID + ", value=" + value + ")";
    }
}

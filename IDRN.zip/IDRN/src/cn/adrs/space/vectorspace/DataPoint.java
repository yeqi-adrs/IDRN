package cn.adrs.space.vectorspace;

import java.util.Iterator;
import java.util.Set;

public interface DataPoint 
{
	void setID(Object id);

	Object getID();

	int getClassLabel();

	double getFloatLabel();

	boolean isLabeled();

	void setLabel(int label);

	void addFeature(Feature featureNode);

	int getFeatureNum();

	Iterator getFeatures();

	Feature getFeature(int i);

	void sortIndex();

	void addLabel(int label);

	boolean isMultiLabel();

	Set<Integer> getLabelSet();

	String toString();
}